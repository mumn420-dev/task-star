# ⭐ Task Star — Weekly Challenge Game

A fun, family-friendly weekly task tracker where contestants (kids, family members, whoever!) earn stars by completing daily tasks. Progress accumulates across the week, and the champion is crowned on day 7.

## ✨ Features

- **Daily tasks** — Add tasks for each contestant; checking them off earns ⭐ stars
- **Daily reset** — Tasks reset every new calendar day automatically
- **Weekly progress bar** — Accumulates locked-in scores from every past day, so yesterday's effort shows up in today's bar
- **Streak tracking** — Consecutive productive days build a 🔥 streak
- **Live leaderboard** — See who's winning at any moment
- **Week champion** — After 7 days, crown the winner with 🥇🥈🥉 medals
- **No account needed** — Everything saves to your browser automatically (localStorage)

## 🎯 How Scoring Works

| Action | Points |
|--------|--------|
| Each completed task | +10 ⭐ |
| Max per day (10 tasks) | 100 pts |
| Max over the full week | 700 pts |

Tasks reset each day but your **weekly score keeps growing** — so staying consistent every day is how you win.

## 🚀 Play It Now

**[👉 Open Task Star](https://YOUR-USERNAME.github.io/task-star/)**

*(Replace with your actual GitHub Pages URL after deploying)*

---

## 🌐 Deploy to GitHub Pages (step by step)

### Option A — Easiest (no Git required)

1. Go to [github.com](https://github.com) and sign in (or create a free account)
2. Click the **+** button → **New repository**
3. Name it `task-star` (or anything you like)
4. Make sure it's set to **Public**
5. Click **Create repository**
6. On the next page, click **uploading an existing file**
7. Drag `index.html` and `README.md` into the upload area
8. Click **Commit changes**
9. Go to **Settings** → **Pages** (in the left sidebar)
10. Under *Source*, choose **Deploy from a branch**
11. Set Branch to `main` and folder to `/ (root)` → click **Save**
12. Wait ~60 seconds, then visit `https://YOUR-USERNAME.github.io/task-star/`

### Option B — Using Git

```bash
# Clone your new empty repo
git clone https://github.com/YOUR-USERNAME/task-star.git
cd task-star

# Copy the files in
cp /path/to/index.html .
cp /path/to/README.md .

# Push
git add .
git commit -m "🌟 Launch Task Star"
git push origin main
```

Then enable GitHub Pages in **Settings → Pages** as in step 9–12 above.

---

## 💡 Tips

- **Multiple devices** — Each browser/device keeps its own scores in localStorage. For a shared family leaderboard, use one shared device (e.g. a family tablet).
- **Week resets** — The app detects Monday automatically and resets weekly scores, so you never need to do it manually.
- **Task limit** — Only the first 10 completed tasks count toward the daily max (100 pts). You can add more tasks than that, but scoring caps there.
- **Rename tasks** — Double-click any task name to edit it in place.

## 🛠️ Tech Stack

Pure HTML + CSS + JavaScript — no frameworks, no build step, no server needed. Just open `index.html` in any browser and it works.

---

Made with ❤️ and ⭐
